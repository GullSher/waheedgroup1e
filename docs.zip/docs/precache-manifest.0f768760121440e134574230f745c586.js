self.__precacheManifest = [
  {
    "revision": "5037c2ecc0f5d22c7474",
    "url": "/waheedgroup1e/static/css/main.fcec6e31.chunk.css"
  },
  {
    "revision": "5037c2ecc0f5d22c7474",
    "url": "/waheedgroup1e/static/js/main.3f458fc5.chunk.js"
  },
  {
    "revision": "5f120e8488f446be92fe",
    "url": "/waheedgroup1e/static/js/runtime~main.69ff8dc7.js"
  },
  {
    "revision": "97141ec4e59627e2009e",
    "url": "/waheedgroup1e/static/css/2.c393cd94.chunk.css"
  },
  {
    "revision": "97141ec4e59627e2009e",
    "url": "/waheedgroup1e/static/js/2.65e57b6b.chunk.js"
  },
  {
    "revision": "8ae7b43dd45a45f7220c",
    "url": "/waheedgroup1e/static/js/3.22acface.chunk.js"
  },
  {
    "revision": "86f1ffdb0b871a47b0484c5c62ab4fa5",
    "url": "/waheedgroup1e/static/media/17346oil.86f1ffdb.jpg"
  },
  {
    "revision": "86f1ffdb0b871a47b0484c5c62ab4fa5",
    "url": "/waheedgroup1e/static/media/17346oil-01.86f1ffdb.jpg"
  },
  {
    "revision": "56bbf4b935a9b41a16d1390e87790fec",
    "url": "/waheedgroup1e/static/media/logo.56bbf4b9.png"
  },
  {
    "revision": "9b3d90b363efefc44d0227c92d54ab14",
    "url": "/waheedgroup1e/static/media/577475img-20190206-wa0003.9b3d90b3.jpg"
  },
  {
    "revision": "f7a1aa62f92f4b24c406cff4f66e2c1b",
    "url": "/waheedgroup1e/static/media/46306img-20190411-wa0007.f7a1aa62.jpg"
  },
  {
    "revision": "be4f5f2f8089fb66fbb47e20c1c1d357",
    "url": "/waheedgroup1e/static/media/668220img_9613.be4f5f2f.jpg"
  },
  {
    "revision": "6f05746490620bc8566848fcadfb592e",
    "url": "/waheedgroup1e/static/media/488762capture.6f057464.jpg"
  },
  {
    "revision": "c546962995f0a2f7c73eb4238651945b",
    "url": "/waheedgroup1e/static/media/485289img_9632.c5469629.jpg"
  },
  {
    "revision": "53647dcfec7fd539f7938515ed6cb541",
    "url": "/waheedgroup1e/static/media/413919img_9623.53647dcf.jpg"
  },
  {
    "revision": "a71c40966f31f38f2c85a8139aec9050",
    "url": "/waheedgroup1e/static/media/waheed.a71c4096.jpg"
  },
  {
    "revision": "fe0170b132e5a088a3f1a19452d12fbe",
    "url": "/waheedgroup1e/static/media/oil&ghee.fe0170b1.jpg"
  },
  {
    "revision": "455e9ab73c232cef5200071933120ee0",
    "url": "/waheedgroup1e/static/media/industrialFat.455e9ab7.jpg"
  },
  {
    "revision": "929840caddaff8bcd9f0c5f98c7d94cf",
    "url": "/waheedgroup1e/static/media/wcc-03.929840ca.jpg"
  },
  {
    "revision": "65d29ca0d1eac6220779c220dc1cb9ec",
    "url": "/waheedgroup1e/static/media/energySector.65d29ca0.jpg"
  },
  {
    "revision": "05e3728d5b72988751314c388550c353",
    "url": "/waheedgroup1e/static/media/transport-02.05e3728d.jpg"
  },
  {
    "revision": "430f57eea3a789835fc023d061027229",
    "url": "/waheedgroup1e/static/media/c1.430f57ee.png"
  },
  {
    "revision": "6ba288b4c8d9033f3577cdc6dcd1dc00",
    "url": "/waheedgroup1e/static/media/oil-01.6ba288b4.jpg"
  },
  {
    "revision": "6f05746490620bc8566848fcadfb592e",
    "url": "/waheedgroup1e/static/media/110844capture.6f057464.jpg"
  },
  {
    "revision": "04fa7bb7615decd736227126528b0c48",
    "url": "/waheedgroup1e/static/media/704885.04fa7bb7.jpg"
  },
  {
    "revision": "7f02e3a4f58fa421bcf8b7b64612a758",
    "url": "/waheedgroup1e/static/media/20995017.7f02e3a4.jpg"
  },
  {
    "revision": "2d96ffd5051fd5db463c699e9a22e518",
    "url": "/waheedgroup1e/static/media/10468916.2d96ffd5.jpg"
  },
  {
    "revision": "c40d843b5d63ec9a3edd2c8d35619260",
    "url": "/waheedgroup1e/static/media/75450115.c40d843b.jpg"
  },
  {
    "revision": "8369c46d344b697b13d36b142fc28600",
    "url": "/waheedgroup1e/static/media/14463813.8369c46d.jpg"
  },
  {
    "revision": "ad1ccf9a962bdf0784edf1b19161d6e4",
    "url": "/waheedgroup1e/static/media/59549814.ad1ccf9a.jpg"
  },
  {
    "revision": "adea5cfceb956bb3af1a88bfdc6b945a",
    "url": "/waheedgroup1e/static/media/60889512.adea5cfc.jpg"
  },
  {
    "revision": "72320c91855bb3c2ff0c7a5c2b37fb86",
    "url": "/waheedgroup1e/static/media/39035211.72320c91.jpg"
  },
  {
    "revision": "2dcc0c6dc2a53cab214a46b1fccf5e62",
    "url": "/waheedgroup1e/static/media/96214410.2dcc0c6d.jpg"
  },
  {
    "revision": "c3c612baf43343860a8c984276caa04e",
    "url": "/waheedgroup1e/static/media/3582498.c3c612ba.jpg"
  },
  {
    "revision": "d8156033b0aa71436f146a57a448b0c0",
    "url": "/waheedgroup1e/static/media/1253855.d8156033.jpg"
  },
  {
    "revision": "3ba237508aaa87b9903a3a995c9264ea",
    "url": "/waheedgroup1e/static/media/25526.3ba23750.jpg"
  },
  {
    "revision": "f5e0cbb266a99f80104816014bca020c",
    "url": "/waheedgroup1e/static/media/8093154.f5e0cbb2.jpg"
  },
  {
    "revision": "6da4bcb67d583e0b817106d79a400c43",
    "url": "/waheedgroup1e/static/media/5437082.6da4bcb6.jpg"
  },
  {
    "revision": "7088ed94b690b317faceb2bf6ad43a95",
    "url": "/waheedgroup1e/static/media/2700551.7088ed94.jpg"
  },
  {
    "revision": "ca0d0e975533766d504d42b0db509df4",
    "url": "/waheedgroup1e/static/media/laraibinn.ca0d0e97.jpg"
  },
  {
    "revision": "a8fa8285b505f6169e36638683bf701d",
    "url": "/waheedgroup1e/static/media/c2.a8fa8285.png"
  },
  {
    "revision": "ae96663d888bde2d05c6b30d82e9b4a0",
    "url": "/waheedgroup1e/static/media/c3.ae96663d.png"
  },
  {
    "revision": "bb9f12ccd7f710efc4fd0f82864ba1fe",
    "url": "/waheedgroup1e/static/media/c4.bb9f12cc.png"
  },
  {
    "revision": "ce044f0a3367d08ab11018188e7d7766",
    "url": "/waheedgroup1e/static/media/c5.ce044f0a.png"
  },
  {
    "revision": "35f325a143388f2105df3e1b91647687",
    "url": "/waheedgroup1e/static/media/c6.35f325a1.png"
  },
  {
    "revision": "86c8afd5f8ffcdc12a9466dae429b0df",
    "url": "/waheedgroup1e/static/media/c7.86c8afd5.png"
  },
  {
    "revision": "e49ae2de554bbccad7e69ff4fb4912bd",
    "url": "/waheedgroup1e/static/media/c8.e49ae2de.png"
  },
  {
    "revision": "1a7cfce78fd9e8be6b0d31b35acaf8cb",
    "url": "/waheedgroup1e/static/media/FaadWaheed1.1a7cfce7.jpeg"
  },
  {
    "revision": "e9c4586957743bd54e7428dd67ae6ac6",
    "url": "/waheedgroup1e/static/media/731104img-20190411-wa0002.e9c45869.jpg"
  },
  {
    "revision": "534146b03345ee2c37219a785dce7de3",
    "url": "/waheedgroup1e/static/media/372027img-20190411-wa0004.534146b0.jpg"
  },
  {
    "revision": "8d4abc8a5d9850c9be2d36c8490c7c51",
    "url": "/waheedgroup1e/static/media/61547img-20190913-wa0067.8d4abc8a.jpg"
  },
  {
    "revision": "8aaa4ce2265963be792c16de421f4cd3",
    "url": "/waheedgroup1e/static/media/awais.8aaa4ce2.jpg"
  },
  {
    "revision": "ca0d0e975533766d504d42b0db509df4",
    "url": "/waheedgroup1e/static/media/laraibInn1.ca0d0e97.jpg"
  },
  {
    "revision": "a14bd12d2cec9d8dcc95494a9123af3e",
    "url": "/waheedgroup1e/static/media/WhaeedHafeez2.a14bd12d.jpeg"
  },
  {
    "revision": "a07ac4cbc97184d14981d30c17622302",
    "url": "/waheedgroup1e/static/media/Kadija.a07ac4cb.png"
  },
  {
    "revision": "93e86c34c96409c4675065c658042b5f",
    "url": "/waheedgroup1e/static/media/Fahadhammad.93e86c34.png"
  },
  {
    "revision": "6f6e1ce52f86db7cb01ba7ab1afc606d",
    "url": "/waheedgroup1e/static/media/aklogo.6f6e1ce5.jpeg"
  },
  {
    "revision": "489e85e6f3cf09d6db87a3a67f9e8ae3",
    "url": "/waheedgroup1e/static/media/690525img_9609.489e85e6.jpg"
  },
  {
    "revision": "7f2ec7f9118e745e63c45ae902730409",
    "url": "/waheedgroup1e/static/media/306421img_9600.7f2ec7f9.jpg"
  },
  {
    "revision": "d640e49e06a5ad2b0126fc36d768d5e5",
    "url": "/waheedgroup1e/static/media/832149img_9576.d640e49e.jpg"
  },
  {
    "revision": "52796af1688f564c3a26556fb5672eb6",
    "url": "/waheedgroup1e/static/media/151329img_9566.52796af1.jpg"
  },
  {
    "revision": "60af6d20d7204b7c61a933cb351f9d6e",
    "url": "/waheedgroup1e/static/media/bg-breadcrumb-1.60af6d20.jpg"
  },
  {
    "revision": "f151a562a0264b3ac15968808fe1dab7",
    "url": "/waheedgroup1e/static/media/bg11.f151a562.jpg"
  },
  {
    "revision": "343f56d05d3664aa06a41e99631d8c97",
    "url": "/waheedgroup1e/static/media/map.343f56d0.png"
  },
  {
    "revision": "dc74d0fc4cd1d55ea86607ef3a4bd4b7",
    "url": "/waheedgroup1e/static/media/5.dc74d0fc.png"
  },
  {
    "revision": "da510f60fcff7ce89cd25ea3511bfef4",
    "url": "/waheedgroup1e/static/media/3.da510f60.png"
  },
  {
    "revision": "bfc9b983b4028011805677d7854507e9",
    "url": "/waheedgroup1e/static/media/9.bfc9b983.png"
  },
  {
    "revision": "a1a33080cfc1d6ebb9f1f72f1d667c60",
    "url": "/waheedgroup1e/static/media/2.a1a33080.png"
  },
  {
    "revision": "ea3e17623ad2e48de000bb132ee37a48",
    "url": "/waheedgroup1e/static/media/10.ea3e1762.png"
  },
  {
    "revision": "3f088219ad09933e3e00315a64820310",
    "url": "/waheedgroup1e/static/media/11.3f088219.png"
  },
  {
    "revision": "aa61a0cf28c28507e309d38cdcc1f7dc",
    "url": "/waheedgroup1e/static/media/14.aa61a0cf.png"
  },
  {
    "revision": "aa9021d2ab1f9e5fb1101b2544cd8240",
    "url": "/waheedgroup1e/static/media/loading.aa9021d2.gif"
  },
  {
    "revision": "62423a5159b09518d8eaf5a660e82356",
    "url": "/waheedgroup1e/static/media/close.62423a51.png"
  },
  {
    "revision": "88ab8ad95a8055d0f3dc4f7dfa075ba0",
    "url": "/waheedgroup1e/static/media/8.88ab8ad9.png"
  },
  {
    "revision": "d35f4a25085e37219faf015fad06baeb",
    "url": "/waheedgroup1e/static/media/12.d35f4a25.png"
  },
  {
    "revision": "c9a047806986642d66a036c5ed13a5db",
    "url": "/waheedgroup1e/static/media/close@2x.c9a04780.png"
  },
  {
    "revision": "aa9021d2ab1f9e5fb1101b2544cd8240",
    "url": "/waheedgroup1e/static/media/loading@2x.aa9021d2.gif"
  },
  {
    "revision": "984381ca77db27cd5428627fe933b508",
    "url": "/waheedgroup1e/static/media/ajaxloader.984381ca.gif"
  },
  {
    "revision": "5e5f4078d2c175131df059051d0fc6f7",
    "url": "/waheedgroup1e/static/media/bg-01.5e5f4078.jpg"
  },
  {
    "revision": "67300ba143097fab44cef6e20e470c0d",
    "url": "/waheedgroup1e/static/media/grabbing.67300ba1.png"
  },
  {
    "revision": "701ec624250025426113e34fca9de341",
    "url": "/waheedgroup1e/index.html"
  }
];